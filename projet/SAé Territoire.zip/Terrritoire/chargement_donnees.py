# ============================================================
# chargement_donnees.py
# Lecture et préparation des fichiers Excel
# ============================================================

import pandas as pd
import os

FICHIERS_REQUIS = [
    'Tournee.xlsx',
    'indisponibilite.xlsx',
    'vehicules.xlsx',
    'preleveurs_trimestriel.xlsx',
]

def verifier_fichiers():
    """Vérifie que tous les fichiers Excel sont présents."""
    manquants = [f for f in FICHIERS_REQUIS if not os.path.exists(f)]
    if manquants:
        raise FileNotFoundError(
            "\n❌ Fichiers manquants :\n"
            + "\n".join(f"   - {f}" for f in manquants)
            + "\n\n   Placez tous les fichiers Excel dans le même dossier que app.py."
        )

def charger_donnees():
    """
    Charge et nettoie les 4 fichiers Excel.
    Retourne : df_tournee, df_indispo, df_pref, df_oblig, df_veh_dispo, df_presence
    """
    verifier_fichiers()

    # ── Tournées ──────────────────────────────────────────────
    df_tournee = pd.read_excel('Tournee.xlsx', sheet_name='Exporter la feuille de calcul')
    df_tournee.columns = ['DATE', 'DSTOURNEE', 'TYPE_TOURNEE', 'PRELEVEUR']
    df_tournee['DATE'] = pd.to_datetime(df_tournee['DATE']).dt.normalize()
    df_tournee = df_tournee[df_tournee['PRELEVEUR'].notna()].copy()
    df_tournee = df_tournee[df_tournee['PRELEVEUR'].str.startswith('PR')].copy()

    # ── Indisponibilités préleveurs ───────────────────────────
    df_indispo = pd.read_excel('indisponibilite.xlsx', sheet_name='Exporter la feuille de calcul')
    df_indispo.columns = ['DEBUT', 'FIN', 'MOTIF', 'PRELEVEUR']
    df_indispo['DEBUT'] = pd.to_datetime(df_indispo['DEBUT']).dt.normalize()
    df_indispo['FIN']   = pd.to_datetime(df_indispo['FIN']).dt.normalize()
    df_indispo = df_indispo[df_indispo['PRELEVEUR'].str.startswith('PR')].copy()

    # ── Préférences véhicules ─────────────────────────────────
    df_pref = pd.read_excel('vehicules.xlsx', sheet_name='préférence', header=1)
    df_pref = df_pref.dropna(subset=[df_pref.columns[0]]).copy()
    df_pref.columns = ['IMMAT', 'TYPE_VEH', 'LOGO', 'PARAPHE', 'NOM']
    df_pref = df_pref[df_pref['IMMAT'].astype(str).str.contains('-')].copy().reset_index(drop=True)

    # ── Obligations véhicules par type de tournée ─────────────
    df_oblig = pd.read_excel('vehicules.xlsx', sheet_name='Obligation des véhicules', header=1)
    df_oblig = df_oblig.iloc[:, 1:3].dropna().copy()
    df_oblig.columns = ['TYPE_TOURNEE', 'TYPE_VEH_OBLIG']
    df_oblig = df_oblig[df_oblig['TYPE_TOURNEE'] != 'Type de tournée'].copy()

    # ── Disponibilités véhicules ──────────────────────────────
    df_veh_dispo = pd.read_excel('vehicules.xlsx', sheet_name='Véhicules dispo')
    df_veh_dispo = df_veh_dispo.iloc[:, :4].copy()
    df_veh_dispo.columns = ['IMMAT', 'DATE', 'DISPO', 'MOTIF']
    df_veh_dispo['DATE'] = pd.to_datetime(df_veh_dispo['DATE']).dt.normalize()

    # ── Présences préleveurs ──────────────────────────────────
    df_presence = pd.read_excel('preleveurs_trimestriel.xlsx', sheet_name='PRE')
    df_presence.columns = ['MATRICULE', 'NOM_PRENOM', 'DATE', 'NOM_JOUR', 'PRESENCE']
    df_presence['DATE'] = pd.to_datetime(df_presence['DATE']).dt.normalize()
    df_presence['PRESENCE'] = df_presence['PRESENCE'].astype(str).str.strip()

    # Correspondance Nom → Paraphe
    nom_to_paraphe = {
        r['NOM'].strip(): r['PARAPHE'].strip()
        for _, r in df_pref.iterrows()
        if pd.notna(r['PARAPHE']) and pd.notna(r['NOM'])
    }
    df_presence['PARAPHE'] = df_presence['NOM_PRENOM'].map(nom_to_paraphe)

    return df_tournee, df_indispo, df_pref, df_oblig, df_veh_dispo, df_presence

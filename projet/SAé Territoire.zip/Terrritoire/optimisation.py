# ============================================================
# optimisation.py
# Analyse et suggestions d'optimisation des associations
#
# Choix techniques :
#   - Calculs vectorisés pandas (groupby/agg) : évite les boucles
#     Python explicites, x10 plus rapide sur de grands volumes
#   - Mise en cache dans app.py (_cache_optimisation) : ce rapport
#     est coûteux à calculer, inutile de le recalculer à chaque requête
#   - Seuils configurables : 90% = bon, 70% = moyen, <70% = faible
#     (objectif métier LEAV : 1 véhicule = 1 préleveur toute l'année)
#   - Filtres anti-bruit :
#       * Préleveurs sans véhicule attitré exclus des suggestions
#       * Jours avec < 3 préleveurs exclus des jours critiques
# ============================================================

import pandas as pd
import numpy as np


def analyser_optimisation(df_res, pref_veh, immat_to_type):

    # ── Score global (vectorisé) ──────────────────────────────
    # Indicateur principal : % d'associations où le préleveur
    # a son propre véhicule (objectif LEAV : atteindre 90%)
    total      = len(df_res)
    n_attitré  = (df_res['STATUT'] == 'Véhicule attitré').sum()
    n_remplace = df_res['STATUT'].str.startswith('Remplacement').sum()
    n_auto     = (df_res['STATUT'] == 'Affectation automatique').sum()
    n_indispo  = df_res['VEHICULE'].isna().sum()
    n_modifie  = df_res['MODIFIE'].sum()
    score_global = round(100 * n_attitré / total, 1) if total > 0 else 0

    # ── Fidélité par préleveur (vectorisé) ────────────────────
    df = df_res.copy()
    df['VEH_ATTITRÉ'] = df['PRELEVEUR'].map(pref_veh)
    df['EST_ATTITRÉ'] = (df['VEHICULE'] == df['VEH_ATTITRÉ']) & df['VEH_ATTITRÉ'].notna()
    df['A_VEHICULE']  = df['VEHICULE'].notna() & (df['VEHICULE'] != '')

    grp = df.groupby('PRELEVEUR').agg(
        nb_jours        =('PRELEVEUR', 'count'),
        nb_attitré      =('EST_ATTITRÉ', 'sum'),
        nb_avec_vehicule=('A_VEHICULE', 'sum'),
    ).reset_index()

    grp['VEH_ATTITRÉ']     = grp['PRELEVEUR'].map(pref_veh)
    grp['nb_remplacement'] = grp['nb_avec_vehicule'] - grp['nb_attitré']
    grp['fidelite']        = (100 * grp['nb_attitré'] / grp['nb_avec_vehicule'].replace(0, np.nan)).fillna(0).round(1)
    grp['statut']          = grp['fidelite'].apply(lambda f: '✓ Bon' if f >= 90 else ('⚠ Moyen' if f >= 70 else '✗ Faible'))
    grp = grp.sort_values('fidelite')

    fidelite_par_pr = [{
        'preleveur'      : r['PRELEVEUR'],
        'veh_attitré'    : r['VEH_ATTITRÉ'] if pd.notna(r['VEH_ATTITRÉ']) else None,
        'nb_jours'       : int(r['nb_jours']),
        'nb_attitré'     : int(r['nb_attitré']),
        'nb_remplacement': int(r['nb_remplacement']),
        'fidelite'       : float(r['fidelite']),
        'statut'         : r['statut'],
    } for _, r in grp.iterrows()]

    # ── Jours problématiques (vectorisé) ─────────────────────
    grp_j = df.groupby('DATE').agg(
        nb_preleveurs   =('PRELEVEUR', 'count'),
        nb_attitré      =('EST_ATTITRÉ', 'sum'),
        nb_remplacement =('STATUT', lambda x: x.str.startswith('Remplacement').sum()),
        nb_indispo      =('VEHICULE', lambda x: x.isna().sum()),
    ).reset_index()

    grp_j['taux_attitré'] = (100 * grp_j['nb_attitré'] / grp_j['nb_preleveurs'].replace(0, np.nan)).fillna(0).round(1)
    grp_j = grp_j.sort_values('taux_attitré')

    jours = [{
        'date'           : r['DATE'],
        'nb_preleveurs'  : int(r['nb_preleveurs']),
        'nb_attitré'     : int(r['nb_attitré']),
        'nb_remplacement': int(r['nb_remplacement']),
        'nb_indispo'     : int(r['nb_indispo']),
        'taux_attitré'   : float(r['taux_attitré']),
    } for _, r in grp_j.iterrows()]

    # ── Suggestions ───────────────────────────────────────────
    # Génère des alertes actionnables pour les gestionnaires :
    #   - FIDÉLITÉ FAIBLE : préleveur avec son attitré < 70% du temps
    #     ET plus de 3 remplacements (filtre le bruit statistique)
    #   - JOUR CRITIQUE : journée avec 2+ préleveurs sans véhicule
    #     (filtre les jours avec < 3 préleveurs pour éviter les faux positifs)
    suggestions = []

    for item in fidelite_par_pr:
        # Bug fix : ignorer les préleveurs sans véhicule attitré (fidélité 0% non pertinente)
        if item['veh_attitré'] is None:
            continue
        if item['fidelite'] < 70 and item['nb_remplacement'] > 3:
            suggestions.append({
                'type'  : 'FIDÉLITÉ FAIBLE',
                'niveau': 'warning',
                'detail': f"{item['preleveur']} utilise son véhicule attitré ({item['veh_attitré']}) seulement {item['fidelite']}% du temps ({item['nb_remplacement']} remplacements)",
                'action': f"Vérifier la disponibilité de {item['veh_attitré']} sur la période",
            })

    for jour in jours:
        # Bug fix : ignorer les jours avec moins de 3 préleveurs (taux trompeur)
        if jour['nb_preleveurs'] < 3:
            continue
        if jour['nb_indispo'] >= 2:
            suggestions.append({
                'type'  : 'JOUR CRITIQUE',
                'niveau': 'danger',
                'detail': f"Le {jour['date']} : {jour['nb_indispo']} préleveur(s) sans véhicule assigné",
                'action': f"Revoir les disponibilités véhicules pour le {jour['date']}",
            })

    return {
        'score_global'   : score_global,
        'total'          : int(total),
        'n_attitré'      : int(n_attitré),
        'n_remplacement' : int(n_remplace),
        'n_auto'         : int(n_auto),
        'n_indispo'      : int(n_indispo),
        'n_modifie'      : int(n_modifie),
        'fidelite_par_pr': fidelite_par_pr,
        'jours'          : jours,
        'suggestions'    : suggestions,
        'nb_suggestions' : len(suggestions),
    }

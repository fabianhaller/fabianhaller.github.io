# ============================================================
# association.py
# Algorithme de calcul des associations véhicule ↔ préleveur
#
# Choix techniques :
#   - Pandas DataFrame : traitement vectorisé des données tabulaires,
#     nettement plus performant que des boucles Python sur 388 lignes
#   - Index de lookup (dict) : O(1) au lieu de O(n) pour les accès
#     fréquents (veh_dispo_idx, presence_idx, indispo_set)
#   - Tri numérique des préleveurs : évite l'ordre lexicographique
#     (PR10 avant PR2) qui fausserait l'attribution des véhicules
#   - Priorités d'affectation (attitré > remplacement compatible >
#     remplacement libre > aucun) : garantit la fidélité maximale
# ============================================================

import pandas as pd
from datetime import timedelta


def calculer_associations(df_tournee, df_indispo, df_pref, df_oblig, df_veh_dispo, df_presence):
    """
    Calcule les associations véhicule ↔ préleveur pour chaque jour de tournée.

    Règles appliquées (dans l'ordre) :
      1. Si le préleveur est indisponible → pas de véhicule assigné
      2. Si le véhicule attitré est disponible et compatible → on l'attribue
      3. Si le véhicule attitré est indisponible ou incompatible → remplacement
      4. Si aucun véhicule disponible → alerte

    Retourne :
      df_resultats   : DataFrame des associations
      df_alertes     : DataFrame des alertes
      pref_veh       : dict { paraphe → immat attitré }
      immat_to_type  : dict { immat → type véhicule }
      tous_veh_leav  : liste des immatriculations LEAV
      veh_dispo_idx  : dict { (immat, date) → 0/1 }
    """

    # ── Index de lookup pour les performances ─────────────────
    pref_veh = {
        r['PARAPHE'].strip(): r['IMMAT'].strip()
        for _, r in df_pref.iterrows()
        if pd.notna(r['PARAPHE'])
    }

    immat_to_type = {
        r['IMMAT'].strip(): str(r.get('TYPE_VEH', '')).strip().upper() if pd.notna(r.get('TYPE_VEH')) else ''
        for _, r in df_pref.iterrows()
        if pd.notna(r['IMMAT'])
    }

    oblig_dict = {}
    for _, r in df_oblig.iterrows():
        k = str(r['TYPE_TOURNEE']).strip().upper()
        oblig_dict.setdefault(k, []).append(str(r['TYPE_VEH_OBLIG']).strip().upper())

    veh_dispo_idx = {
        (r['IMMAT'].strip(), r['DATE']): int(r['DISPO'])
        for _, r in df_veh_dispo.iterrows()
    }

    presence_idx = {
        (r['PARAPHE'].strip(), r['DATE']): r['PRESENCE']
        for _, r in df_presence.iterrows()
        if pd.notna(r['PARAPHE'])
    }

    # Indisponibilités sur plage de dates → expansion jour par jour
    indispo_set   = set()
    indispo_motif = {}
    for _, r in df_indispo.iterrows():
        d = r['DEBUT']
        while d <= r['FIN']:
            indispo_set.add((r['PRELEVEUR'].strip(), d))
            indispo_motif[(r['PRELEVEUR'].strip(), d)] = r['MOTIF']
            d += timedelta(days=1)

    tous_veh_leav = [
        r['IMMAT'].strip()
        for _, r in df_pref.iterrows()
        if str(r.get('LOGO', '')).strip() == 'LEAV' and pd.notna(r['IMMAT'])
    ]

    # ── Fonctions utilitaires internes ─────────────────────────

    def vehicule_disponible(immat, date):
        """Retourne True si le véhicule est disponible ce jour."""
        return veh_dispo_idx.get((immat, date), 1) == 1

    def preleveur_disponible(paraphe, date):
        """Retourne (True/False, motif)."""
        if presence_idx.get((paraphe, date), '1') == '0':
            return False, 'Absent (planning)'
        if (paraphe, date) in indispo_set:
            return False, f"Indispo: {indispo_motif.get((paraphe, date), 'N/A')}"
        return True, ''

    def vehicule_compatible(type_veh, type_tournee):
        """Vérifie la compatibilité véhicule / type de tournée.
        Exemple : tournée SAUR nécessite un attelage (défini dans vehicules.xlsx).
        La vérification est insensible à la casse (tout converti en majuscules).
        Retourne True si aucune contrainte n'est définie pour ce type de tournée.
        """
        if not type_veh or not type_tournee:
            return True
        tv, tt = type_veh.upper(), type_tournee.upper()
        for kw, contraintes in oblig_dict.items():
            if kw in tt:
                for c in contraintes:
                    if c not in tv:
                        return False
        return True

    def trouver_remplacement(date, type_tournee, deja_assignes):
        """
        Cherche un véhicule de remplacement :
          1. Compatible avec la tournée
          2. Libre (peu importe la compatibilité)
        """
        # Priorité 1 : compatible
        for immat in tous_veh_leav:
            if immat in deja_assignes or not vehicule_disponible(immat, date):
                continue
            if vehicule_compatible(immat_to_type.get(immat, ''), type_tournee):
                return immat, 'Remplacement compatible'
        # Priorité 2 : libre
        for immat in tous_veh_leav:
            if immat in deja_assignes or not vehicule_disponible(immat, date):
                continue
            return immat, 'Remplacement libre'
        return None, 'Aucun véhicule disponible'

    # ── Calcul principal ───────────────────────────────────────
    resultats = []
    alertes   = []

    for date in sorted(df_tournee['DATE'].unique()):
        df_jour       = df_tournee[df_tournee['DATE'] == date]
        deja_assignes = set()

        for paraphe in sorted(df_jour['PRELEVEUR'].unique(), key=lambda x: int(x.replace('PR','')) if x.replace('PR','').isdigit() else 9999):
            tournees = df_jour[df_jour['PRELEVEUR'] == paraphe]['TYPE_TOURNEE'].tolist()
            type_t   = tournees[0] if tournees else ''

            # Vérification disponibilité préleveur
            ok, motif = preleveur_disponible(paraphe, date)
            if not ok:
                alertes.append({
                    'DATE': str(date.date()), 'PRELEVEUR': paraphe,
                    'TYPE': 'PRÉLEVEUR INDISPONIBLE', 'DETAIL': motif, 'TOURNEE': type_t
                })
                resultats.append({
                    'DATE': str(date.date()), 'PRELEVEUR': paraphe,
                    'VEHICULE': None, 'TYPE_VEHICULE': '', 'STATUT': motif,
                    'TOURNEE': type_t, 'NB_TOURNEES': len(tournees), 'MODIFIE': False
                })
                continue

            # Recherche du véhicule
            vp = pref_veh.get(paraphe)
            immat_final, statut = None, ''

            if vp:
                if vehicule_disponible(vp, date) and vp not in deja_assignes:
                    if vehicule_compatible(immat_to_type.get(vp, ''), type_t):
                        immat_final, statut = vp, 'Véhicule attitré'
                    else:
                        alertes.append({
                            'DATE': str(date.date()), 'PRELEVEUR': paraphe,
                            'TYPE': 'VÉHICULE INCOMPATIBLE',
                            'DETAIL': f'{vp} incompatible avec {type_t}', 'TOURNEE': type_t
                        })
                        immat_final, statut = trouver_remplacement(date, type_t, deja_assignes)
                else:
                    motif_v = df_veh_dispo[
                        (df_veh_dispo['IMMAT'] == vp) & (df_veh_dispo['DATE'] == date)
                    ]['MOTIF'].values
                    alertes.append({
                        'DATE': str(date.date()), 'PRELEVEUR': paraphe,
                        'TYPE': 'VÉHICULE ATTITRÉ INDISPONIBLE',
                        'DETAIL': f'{vp} — {str(motif_v[0]) if len(motif_v) > 0 and pd.notna(motif_v[0]) else "Motif non renseigné"}',
                        'TOURNEE': type_t
                    })
                    immat_final, statut = trouver_remplacement(date, type_t, deja_assignes)
            else:
                immat_final, statut = trouver_remplacement(date, type_t, deja_assignes)
                if immat_final:
                    statut = 'Affectation automatique'

            if immat_final:
                deja_assignes.add(immat_final)
            else:
                alertes.append({
                    'DATE': str(date.date()), 'PRELEVEUR': paraphe,
                    'TYPE': 'AUCUN VÉHICULE', 'DETAIL': 'Tous véhicules indisponibles',
                    'TOURNEE': type_t
                })

            resultats.append({
                'DATE': str(date.date()), 'PRELEVEUR': paraphe,
                'VEHICULE': immat_final,
                'TYPE_VEHICULE': immat_to_type.get(immat_final, '') if immat_final else '',
                'STATUT': statut, 'TOURNEE': type_t,
                'NB_TOURNEES': len(tournees), 'MODIFIE': False
            })

    df_alertes = pd.DataFrame(alertes) if alertes else pd.DataFrame(
        columns=['DATE', 'PRELEVEUR', 'TYPE', 'DETAIL', 'TOURNEE']
    )

    return (
        pd.DataFrame(resultats),
        df_alertes,
        pref_veh,
        immat_to_type,
        tous_veh_leav,
        veh_dispo_idx,
    )

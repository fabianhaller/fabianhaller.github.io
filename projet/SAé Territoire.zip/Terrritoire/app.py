# ============================================================
# app.py — LEAV Gestion des Véhicules
# Serveur Flask + Routes API
#
# Lancement : C:\ProgramData\Anaconda3\python.exe app.py
# Accès     : http://localhost:5000
#
# Endpoints API :
#   GET  /api/associations        → toutes les associations
#   GET  /api/associations?date=  → associations d'un jour
#   GET  /api/associations?preleveur= → associations d'un préleveur
#   PUT  /api/associations        → modifier une association
#   GET  /api/alertes             → toutes les alertes
#   GET  /api/vehicules           → liste des véhicules
#   GET  /api/preleveurs          → liste des préleveurs + fidélité
#   GET  /api/stats               → statistiques globales
#   GET  /api/export/csv          → export associations CSV
#   GET  /api/export/alertes/csv  → export alertes CSV
#   POST /api/reload              → recharger les fichiers Excel
#   GET  /api/historique          → historique des modifications
# ============================================================

from flask import Flask, jsonify, request, Response, render_template
import os
import pandas as pd
import numpy as np
from datetime import datetime
import csv, io, threading

# Modules du projet
from chargement_donnees import charger_donnees
from association import calculer_associations
from optimisation import analyser_optimisation

DOSSIER = os.path.dirname(os.path.abspath(__file__))
app = Flask(__name__, template_folder=os.path.join(DOSSIER, 'templates'))
_lock = threading.Lock()  # Protection accès concurrent

# ── Historique des modifications manuelles (session courante) ─
_historique = []

# ── Chargement initial des données ───────────────────────────
print("Chargement des données...")
(df_tournee, df_indispo, df_pref,
 df_oblig, df_veh_dispo, df_presence) = charger_donnees()

(df_res, df_alert, pref_veh,
 immat_to_type, tous_veh_leav, veh_dispo_idx) = calculer_associations(
    df_tournee, df_indispo, df_pref, df_oblig, df_veh_dispo, df_presence)

print(f"Prêt — {len(df_res)} associations, {len(df_alert)} alertes")

# ── Cache optimisation (calculé une fois au démarrage) ───────
_cache_optimisation = analyser_optimisation(df_res, pref_veh, immat_to_type)


# ════════════════════════════════════════════════════════════
# ROUTES API
# ════════════════════════════════════════════════════════════

@app.route('/api/associations', methods=['GET'])
def get_associations():
    date_filter = request.args.get('date')
    pr_filter   = request.args.get('preleveur')
    df = df_res.copy()
    if date_filter:
        df = df[df['DATE'] == date_filter]
    if pr_filter:
        df = df[df['PRELEVEUR'] == pr_filter]
    return jsonify(df.replace({np.nan: None}).to_dict(orient='records'))


@app.route('/api/associations', methods=['PUT'])
def update_association():
    """Modifier une association avec contrôle de cohérence."""
    data      = request.json
    date      = data.get('date')
    preleveur = data.get('preleveur')
    new_veh   = data.get('vehicule')

    if not all([date, preleveur]):
        return jsonify({'error': 'Paramètres manquants'}), 400

    mask = (df_res['DATE'] == date) & (df_res['PRELEVEUR'] == preleveur)
    if not mask.any():
        return jsonify({'error': 'Association introuvable'}), 404

    warnings_list = []

    if new_veh:
        date_dt = pd.to_datetime(date)

        # Contrôle 1 : véhicule disponible ce jour
        if veh_dispo_idx.get((new_veh, date_dt), 1) == 0:
            return jsonify({'error': f'Véhicule {new_veh} indisponible ce jour',
                            'type': 'VEHICULE_INDISPONIBLE'}), 409

        # Contrôle 2 : véhicule déjà assigné à quelqu'un d'autre
        deja = df_res[(df_res['DATE'] == date) &
                      (df_res['PRELEVEUR'] != preleveur) &
                      (df_res['VEHICULE'] == new_veh)]
        if len(deja) > 0:
            warnings_list.append(f'Véhicule {new_veh} déjà assigné à {deja.iloc[0]["PRELEVEUR"]} ce jour')

        # Contrôle 3 : compatibilité type de tournée
        type_t = df_res[mask]['TOURNEE'].values[0]
        type_v = immat_to_type.get(new_veh, '')
        if type_t and 'SAUR' in type_t.upper() and 'ATTELAGE' not in type_v.upper():
            warnings_list.append('Tournée SAUR recommande un véhicule avec attelage')

    # Sauvegarde de l'ancienne valeur pour l'historique
    ancien_veh = str(df_res.loc[mask, 'VEHICULE'].values[0])

    with _lock:
        df_res.loc[mask, 'VEHICULE']      = new_veh
        df_res.loc[mask, 'TYPE_VEHICULE'] = immat_to_type.get(new_veh, '') if new_veh else ''
        df_res.loc[mask, 'STATUT']        = 'Modifié manuellement'
        df_res.loc[mask, 'MODIFIE']       = True

    # Enregistrement dans l'historique
    _historique.append({
        'ts'        : datetime.now().isoformat(timespec='seconds'),
        'date'      : date,
        'preleveur' : preleveur,
        'ancien'    : ancien_veh,
        'nouveau'   : new_veh or '—',
    })

    return jsonify({
        'success'     : True,
        'warnings'    : warnings_list,
        'association' : df_res[mask].replace({np.nan: None}).to_dict(orient='records')[0],
    })


@app.route('/api/alertes', methods=['GET'])
def get_alertes():
    return jsonify(df_alert.replace({np.nan: None}).to_dict(orient='records'))


@app.route('/api/vehicules', methods=['GET'])
def get_vehicules():
    date_filter = request.args.get('date')
    vehs = []
    for _, r in df_pref.iterrows():
        if not pd.notna(r['IMMAT']) or '-' not in str(r['IMMAT']):
            continue
        immat     = r['IMMAT'].strip()
        dispo     = True
        assigne_a = None  # Initialisé avant le if pour éviter UnboundLocalError

        if date_filter:
            date_dt   = pd.to_datetime(date_filter)
            dispo     = veh_dispo_idx.get((immat, date_dt), 1) == 1
            row_ass   = df_res[(df_res['DATE'] == date_filter) & (df_res['VEHICULE'] == immat)]
            if len(row_ass) > 0:
                assigne_a = row_ass.iloc[0]['PRELEVEUR']

        vehs.append({
            'immat'     : immat,
            'type'      : str(r.get('TYPE_VEH', '')).strip() if pd.notna(r.get('TYPE_VEH')) else '',
            'logo'      : str(r.get('LOGO', '')).strip() if pd.notna(r.get('LOGO')) else '',
            'paraphe'   : str(r['PARAPHE']).strip() if pd.notna(r.get('PARAPHE')) else None,
            'nom'       : str(r['NOM']).strip() if pd.notna(r.get('NOM')) else None,
            'disponible': dispo,
            'assigne_a' : assigne_a,
        })
    return jsonify(vehs)


@app.route('/api/preleveurs', methods=['GET'])
def get_preleveurs():
    prs = df_res.groupby('PRELEVEUR').size().reset_index(name='nb_jours')
    result = []
    for _, r in prs.iterrows():
        pr    = r['PRELEVEUR']
        vp    = pref_veh.get(pr)
        df_pr = df_res[df_res['PRELEVEUR'] == pr]
        n_attitré = (df_pr['VEHICULE'] == vp).sum() if vp else 0
        n_total   = (df_pr['VEHICULE'].notna() & (df_pr['VEHICULE'] != '')).sum()
        result.append({
            'paraphe'    : pr,
            'veh_attire' : vp,
            'nb_jours'   : int(r['nb_jours']),
            'fidelite'   : round(100 * n_attitré / n_total, 1) if n_total > 0 else 0,
        })
    return jsonify(sorted(result, key=lambda x: int(x['paraphe'].replace('PR', ''))))


@app.route('/api/stats', methods=['GET'])
def get_stats():
    total    = len(df_res)
    attitré  = (df_res['STATUT'] == 'Véhicule attitré').sum()
    remplace = df_res['STATUT'].str.startswith('Remplacement').sum()
    auto     = (df_res['STATUT'] == 'Affectation automatique').sum()
    indispo  = df_res['VEHICULE'].isna().sum()
    modifie  = df_res['MODIFIE'].sum()

    fidelites = []
    for pr, vp in pref_veh.items():
        df_pr = df_res[(df_res['PRELEVEUR'] == pr) & (df_res['VEHICULE'].notna())]
        if len(df_pr) > 0:
            fidelites.append(100 * (df_pr['VEHICULE'] == vp).sum() / len(df_pr))
    fidelite_moy = round(float(np.mean(fidelites)), 1) if fidelites else 0

    return jsonify({
        'total'        : int(total),
        'attire'       : int(attitré),
        'remplacement' : int(remplace),
        'auto'         : int(auto),
        'indisponible' : int(indispo),
        'modifie'      : int(modifie),
        'alertes'      : len(df_alert),
        'fidelite_moy' : fidelite_moy,
        'nb_jours'     : int(df_res['DATE'].nunique()),
        'nb_preleveurs': int(df_res['PRELEVEUR'].nunique()),
        'date_min'     : df_res['DATE'].min(),
        'date_max'     : df_res['DATE'].max(),
    })


@app.route('/api/export/csv', methods=['GET'])
def export_csv():
    """Export des associations en CSV — encodage UTF-8 BOM pour compatibilité Excel."""
    output = io.StringIO()
    output.write('﻿')  # BOM UTF-8 : Excel détecte automatiquement l'encodage
    writer = csv.writer(output, delimiter=';')
    writer.writerow(['DATE', 'PRELEVEUR', 'VEHICULE', 'TYPE_VEHICULE', 'STATUT', 'TOURNEE', 'NB_TOURNEES', 'MODIFIE'])
    for _, r in df_res.iterrows():
        # Nettoyer les valeurs NaN avant écriture
        vehicule     = str(r['VEHICULE']) if not (str(r['VEHICULE']) in ('nan','None','')) else ''
        type_veh     = str(r['TYPE_VEHICULE']) if str(r['TYPE_VEHICULE']) != 'nan' else ''
        tournee      = str(r['TOURNEE']) if str(r['TOURNEE']) != 'nan' else ''
        writer.writerow([r['DATE'], r['PRELEVEUR'], vehicule, type_veh,
                         r['STATUT'], tournee, r['NB_TOURNEES'], r['MODIFIE']])
    output.seek(0)
    return Response(output.getvalue(), mimetype='text/csv; charset=utf-8',
                    headers={'Content-Disposition': 'attachment; filename=associations_export.csv'})


@app.route('/api/export/alertes/csv', methods=['GET'])
def export_alertes_csv():
    """Export des alertes en CSV — encodage UTF-8 BOM pour compatibilité Excel."""
    output = io.StringIO()
    output.write('﻿')  # BOM UTF-8 : Excel détecte automatiquement l'encodage
    writer = csv.writer(output, delimiter=';')
    writer.writerow(['DATE', 'PRELEVEUR', 'TYPE', 'DETAIL', 'TOURNEE'])
    for _, r in df_alert.iterrows():
        # Nettoyer les valeurs NaN avant écriture
        detail  = str(r.get('DETAIL', '')) if str(r.get('DETAIL', '')) != 'nan' else ''
        tournee = str(r.get('TOURNEE', '')) if str(r.get('TOURNEE', '')) != 'nan' else ''
        writer.writerow([r['DATE'], r['PRELEVEUR'], r['TYPE'], detail, tournee])
    output.seek(0)
    return Response(output.getvalue(), mimetype='text/csv; charset=utf-8',
                    headers={'Content-Disposition': 'attachment; filename=alertes_export.csv'})


@app.route('/api/reload', methods=['POST'])
def reload_data():
    """Recharger les fichiers Excel sans redémarrer le serveur."""
    global df_tournee, df_indispo, df_pref, df_oblig, df_veh_dispo, df_presence
    global df_res, df_alert, pref_veh, immat_to_type, tous_veh_leav, veh_dispo_idx
    try:
        with _lock:
            (df_tournee, df_indispo, df_pref,
             df_oblig, df_veh_dispo, df_presence) = charger_donnees()
            (df_res, df_alert, pref_veh,
             immat_to_type, tous_veh_leav, veh_dispo_idx) = calculer_associations(
                df_tournee, df_indispo, df_pref, df_oblig, df_veh_dispo, df_presence)
        global _cache_optimisation
        _cache_optimisation = analyser_optimisation(df_res, pref_veh, immat_to_type)
        return jsonify({'success': True,
                        'associations': len(df_res),
                        'alertes': len(df_alert),
                        'message': f'{len(df_res)} associations et {len(df_alert)} alertes rechargées'})
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/historique', methods=['GET'])
def get_historique():
    """Historique des modifications manuelles (session courante)."""
    return jsonify(list(reversed(_historique)))



@app.route("/api/optimisation", methods=["GET"])
def get_optimisation():
    """Retourne l'analyse en cache (recalculée au reload)."""
    return jsonify(_cache_optimisation)

# ════════════════════════════════════════════════════════════
# INTERFACE WEB
# ════════════════════════════════════════════════════════════

@app.route('/')
def index():
    return render_template('interface.html')


# ════════════════════════════════════════════════════════════
# LANCEMENT
# ════════════════════════════════════════════════════════════

# ════════════════════════════════════════════════════════════
# GESTION DES ERREURS
# ════════════════════════════════════════════════════════════

@app.errorhandler(404)
def page_non_trouvee(e):
    """Page 404 personnalisée — retourne du JSON pour les appels API,
    une page HTML lisible pour les accès navigateur."""
    if request.path.startswith('/api/'):
        return jsonify({'error': 'Endpoint introuvable', 'path': request.path}), 404
    return """<!DOCTYPE html>
<html lang="fr"><head><meta charset="UTF-8"><title>Page introuvable — LEAV</title>
<style>body{font-family:Arial,sans-serif;display:flex;align-items:center;justify-content:center;height:100vh;margin:0;background:#F0F0EE;}
.box{text-align:center;}.icon{font-size:64px;margin-bottom:16px;}.title{font-size:24px;font-weight:700;color:#1A1A1A;margin-bottom:8px;}
.sub{color:#8A8A8A;margin-bottom:24px;}.btn{background:#E3010F;color:#fff;padding:10px 24px;border-radius:6px;text-decoration:none;font-weight:600;}</style>
</head><body><div class="box"><div class="icon">🚐</div>
<div class="title">Page introuvable</div>
<div class="sub">Cette URL n'existe pas dans l'application LEAV.</div>
<a class="btn" href="/">Retour au tableau de bord</a></div></body></html>""", 404


@app.errorhandler(500)
def erreur_serveur(e):
    """Erreur 500 — retourne un message clair plutôt qu'une trace Python."""
    return jsonify({'error': 'Erreur interne du serveur', 'detail': str(e)}), 500


if __name__ == '__main__':
    print("\n" + "=" * 55)
    print("  LEAV — Gestion des Véhicules")
    print("  Interface disponible sur : http://localhost:5000")
    print("=" * 55 + "\n")
    app.run(debug=False, port=5000, host='0.0.0.0')
